package com.example.student_grades_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
